﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Matrix a;
        public int k;
        public int b;
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int m, n;
            m = Convert.ToInt32(textBox1.Text);
            n = Convert.ToInt32(textBox2.Text);
            dataGridView1.RowCount = m;
            dataGridView1.ColumnCount = n;
            a = new Matrix(m, n);
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    dataGridView1.Rows[i].Cells[j].Value = a[i, j].ToString();
            k = a.ColOfMaxNegatives();
            if (radioButton1.Checked == true)
                b = 1;
            else
                if (radioButton2.Checked == true)
                b = 2;
        }
    }
}
