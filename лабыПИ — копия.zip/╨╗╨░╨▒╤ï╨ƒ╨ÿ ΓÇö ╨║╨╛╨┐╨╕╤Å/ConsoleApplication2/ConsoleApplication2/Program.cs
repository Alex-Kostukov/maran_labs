﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {

        /*
        1. Создать не менее двух классов
        2. Создать класс для представления структур данных(как правило, массив).
            В этом классе должны быть индексатор и свойство. 
            Использовать этот класс для решения поставленной задачи,
            объявив там переменную типа класс
         
          Во всех задачах задан двумерный массив, содержащий N строк и M столбцов. 
          Если не оговорено противоположение, то M!=N
             
          Если разность максимального и минимального
          элементов массива больше заданного значения, 
          то найти произведение ненулевых элементов, 
          лежащих выше предпоследней строки массива(пусть N>4)
             */


        class Matrix
        {
            protected double[,] arr;

            public Matrix(int m, int n)
            {
                arr = new double[m, n];
                Random rnd = new Random();
                for (int i = 0; i < arr.GetLength(0); i++)
                    for (int j = 0; j < arr.GetLength(1); j++)
                        arr[i, j] = 10 * rnd.NextDouble() - 5;
            }
            public double this[int p, int q]
            {
                get
                {
                    return arr[p, q];
                }
                set
                {
                    arr[p, q] = value;
                }
            }
            public double Product()
            {
                double d = 1;
                for (int i = 0; i < arr.GetLength(0); i++)
                    for (int j = 0; j < arr.GetLength(1)-2; j++)
                        if (arr[i, j] != 0)
                            d *= arr[i, j];
                return d;
            }
            protected double Max(double[,] arr)
            {
                double m = arr[0, 0];
                for (int i = 0; i < arr.GetLength(0); i++)
                    for (int j = 0; j < arr.GetLength(1); j++)
                        if (arr[i, j] > m)
                            m = arr[i, j];
                return m;
            }
            public double Min(double[,] arr)
            {
                double m = arr[0, 0];
                for (int i = 0; i < arr.GetLength(0); i++)
                    for (int j = 0; j < arr.GetLength(1); j++)
                        if (arr[i, j] < m)
                            m = arr[i, j];
                return m;
            }
            public bool Condition(double k)
            {
                bool b = false;
                for (int i = 0; i < arr.GetLength(0); i++)
                    for (int j = 0; j < arr.GetLength(1); j++)
                        if (Max(arr) - Min(arr) > k)
                            b = true;
                        else
                            b = false;
                return b;
            }

        }

        class Exercise : Matrix
        { 
            public Exercise(int m, int n):base(m,n)
            {
            }
            public void OutputMatrix()
            {
                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                        Console.Write(arr[i, j].ToString("F1") + "\t");
                    Console.WriteLine();
                }
            }
        }
        static void Main(string[] args)
        {
            int m,n;
            double k;

            n = 0;
            Console.WriteLine("Input sizes of matrix: ");
            Console.Write("M: ");
            m = Convert.ToInt32(Console.ReadLine());
            while (n <= 4 || m==n)
            {
                Console.WriteLine("N must be > 4 and M must not be equal to N");
                Console.Write("N: ");
                n = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("Input value for comparance: ");
            Console.Write("value: ");
            k = Convert.ToInt32(Console.ReadLine());

            Exercise a = new Exercise(m,n);
            a.OutputMatrix();

            if (a.Condition(k))
            {
                double p = a.Product();
                Console.WriteLine("Product of non-zero elements is " + p.ToString("F1"));
            }
            else
            {
                Console.WriteLine("Condition is not satisfied");
            }

            Console.ReadLine();
        }
        
    }
}
