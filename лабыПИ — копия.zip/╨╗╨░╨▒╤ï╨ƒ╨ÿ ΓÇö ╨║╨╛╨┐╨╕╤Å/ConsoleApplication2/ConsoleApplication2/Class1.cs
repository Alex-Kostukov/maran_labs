﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    /// <summary>
    /// Class for implementation of 2d array
    /// </summary>
    class Class1
    {
        public double[,] arr;

        public Class1(int m, int n)
        {
            arr = new double[m, n];
            double r;
            Random rnd = new Random();
            for (int i = 0; i < arr.GetLength(0); i++)
                for(int j=0;j<arr.GetLength(1); j++)
                    arr[i, j] = 100 * rnd.NextDouble()-50;
        }

        public double this[int p, int q]
        {
            get
            {
                return arr[p,q];
            }
            set
            {
                arr[p,q] = value;
            }
        }

        protected static double Max(double[,] arr)
        {
            double m = arr[0, 0];
            for (int i = 0; i < arr.GetLength(0); i++)
                for (int j = 0; j < arr.GetLength(1); j++)
                    if (arr[i, j] > m)
                        m = arr[i, j];
            return m;
        }
        public static double Min(double[,] arr)
        {
            double m = arr[0, 0];
            for (int i = 0; i < arr.GetLength(0); i++)
                for (int j = 0; j < arr.GetLength(1); j++)
                    if (arr[i, j] < m)
                        m = arr[i, j];
            return m;
        }
        /// <summary>
        /// Tells if needed condition is satisfied
        /// </summary>
        /// <param name="arr"></param>
        /// <param name="k"></param>
        /// <returns></returns>
        public static bool Condition(double[,] arr, double k)
        {
            bool b = false;
            for (int i = 0; i < arr.GetLength(0); i++)
                for (int j = 0; j < arr.GetLength(1); j++)
                    if (Max(arr) - Min(arr) > k)
                        b = true;
                    else
                        b = false;
            return b;
        }



    }
    class Class2
    {
        public static double Product(double[,] arr)
        {
            double d = 1;
            for (int i = 0; i < arr.GetLength(0); i++)
                for (int j = 0; j < arr.GetLength(1); j++)
                    if (arr[i, j] != 0)
                        d *= arr[i, j];
            return d;
        }
    }
}
