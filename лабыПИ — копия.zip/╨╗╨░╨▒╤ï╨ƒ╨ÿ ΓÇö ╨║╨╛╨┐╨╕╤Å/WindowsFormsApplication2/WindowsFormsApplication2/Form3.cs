﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2;

namespace WindowsFormsApplication2
{
    public partial class Form3 : Form
    {
        public Form2 f22;
        public Matrix matr;
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int m = Convert.ToInt32(textBox1.Text);
            int n = Convert.ToInt32(textBox2.Text);
            matr = new Matrix(m, n);

            dataGridView2.RowCount = m;
            dataGridView2.ColumnCount = n;
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    dataGridView2.Rows[i].Cells[j].Value = matr[i, j].ToString();
            button3.Enabled = true;
            button4.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int[] k = matr.ColsOfMaxNegatives();
            int[] arr;

            if (f22.checkBox1.Checked)
            {
                for (int i = 0; i < k.Length; i++)
                {
                    listBox1.Items.Add("----"+k[i]+"-й"+"----" );
                    if (f22.radioButton1.Checked&(f22.radioButton2.Checked == false))
                        arr = matr.FromMatrToArr(k[i], 2);
                    else
                        arr = matr.FromMatrToArr(k[i]);

                    for (int j = 0; j < arr.Length; j++)
                        listBox1.Items.Add(arr[j].ToString());

                }
            }
            else
            {
                if (f22.radioButton1.Enabled)
                    arr = matr.FromMatrToArr(k[0], 2);
                else
                    arr = matr.FromMatrToArr(k[0], 1);

                for (int i = 0; i < arr.Length; i++)
                    listBox1.Items.Add(arr[i].ToString());
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
                button2.Enabled = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
                button2.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int m = dataGridView2.RowCount;
            int n = dataGridView2.ColumnCount;
            matr = new Matrix(m, n);
            
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    matr[i, j] = Convert.ToInt32(dataGridView2.Rows[i].Cells[j].Value);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
