﻿using System;
using System.Collections.Generic;

namespace ClassLibrary2
{
    public class Matrix
    {
        protected int[,] arr;

        public Matrix(int m, int n)
        {
            arr = new int[m, n];
            Random rnd = new Random();
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    arr[i, j] = rnd.Next(100)-50;
        }
        public int this[int p,int q]
        {
            get
            {
                return arr[p, q];
            }
            set
            {
                arr[p, q] = value;
            }
        }

        public int[] ColsOfMaxNegatives()    //возвращает МАССИВ ИНДЕКСОВ столбцов с наибольшим кол-вом отрицательных элементов
        {
            int[] a1 = new int[arr.GetLength(1)];
            List<int> l2 = new List<int>();     //список ИНДЕКСОВ СТОЛБЦОВ с максимальным содержанием отрицательных элементов
            List<int> l1 = new List<int>();     //отсортированный список КОЛИЧЕСТВ отрицательных элементов

            for (int j = 0; j < arr.GetLength(1); j++)  //по СТОЛБЦАМ
            {
                int c = 0;  //буферная переменная количества отрицательных элементов в текущем столбце
                for (int i = 0; i < arr.GetLength(0); i++)  //по СТРОКАМ
                    if (arr[i, j] < 0)
                        c++;
                l1.Add(c);
            }

            l1.CopyTo(a1);
            l1.Sort();
            l1.Reverse();

            int cmax = l1[0];

            for (int j = 0; j < arr.GetLength(1); j++)  //по СТОЛБЦАМ
            {
                if (a1[j] == cmax)
                    l2.Add(j);
            }

            return l2.ToArray();
        }

        public int[] FromMatrToArr(int k)
        {
            List<int> li = new List<int>();
            int[] mas;
            for (int i = 0; i < arr.GetLength(0); i++)
                li.Add(arr[i, k]);

            mas = li.ToArray();

            return mas;
        }
        public int[] FromMatrToArr(int k, int d) //  d=2 для чётных, d=1 для нечётных
        {
            int c = 0;
            List<int> li = new List<int>();
            int[] mas;
            switch(d){
                case 2:
                    {
                        for (int i = 0; i < arr.GetLength(0); i++)
                            if (arr[i, k] % 2 == 0)
                                li.Add(arr[i, k]);

                        mas = li.ToArray();
                        break;
                    }
                case 1:
                    {
                        for (int i = 0; i < arr.GetLength(0); i++)
                            if (arr[i, k] % 2 != 0)
                                li.Add(arr[i, k]);

                        mas = li.ToArray(); ;
                        break;
                    }
                default:
                    {
                        mas = new int[1];
                        mas[0] = 0;
                        break;
                    }
            }

            return mas;
        }

    }
}
