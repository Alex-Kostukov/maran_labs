﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    /*Определить номер столбца с наибольшим числом отрицательных элементов.
    Сформировать новый одномернй массив из четных элементов исходного.*/
    public partial class Form1 : Form
    {
        Form2 f2;
        public Form1()
        {
            InitializeComponent();
            f2 = new Form2();
            f2.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 ab = new AboutBox1();
            ab.ShowDialog();
        }

        private void variantChoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            f2.Show();
        }

        private void workToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 f3;
            f3 = new Form3();
            f3.f22 = f2;//для обеспечения ссылки на диалоговое окно
            f3.Show();
        }
    }
}
