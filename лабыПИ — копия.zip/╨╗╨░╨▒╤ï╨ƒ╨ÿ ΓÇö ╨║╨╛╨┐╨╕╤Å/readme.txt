lab1: consoleapplication1
lab2: consoleapplication2
lab3: classlibrary1+windowsformapplicaiton1
lab4: classlibrary2+windowsformapplication2