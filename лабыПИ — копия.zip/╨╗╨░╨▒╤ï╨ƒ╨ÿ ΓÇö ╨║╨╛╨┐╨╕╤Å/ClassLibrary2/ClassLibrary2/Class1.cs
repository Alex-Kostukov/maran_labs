﻿using System;

namespace ClassLibrary2
{
    public class Matrix
    {
        protected int[,] arr;

        public Matrix(int m, int n)
        {
            arr = new int[m, n];
            Random rnd = new Random();
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                    arr[i, j] = rnd.Next()*100-50;
        }

        public int ColOfMaxNegatives()
        {
            int k;
            int smax;
            int[] s = new int[arr.GetLength(0)];

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                s[i] = 0;
                for (int j = 0; j < arr.GetLength(1); j++)
                    if (arr[i, j] < 0)
                        s[i] += 1;
            }

            smax = s[0];
            k = 0;

            for (int i = 0; i < arr.GetLength(0); i++)
                if (s[i]>smax)
                {
                    smax = s[i];
                    k = i;
                }
            
            return k;
        }

        public int[] FromMatrToArr(int k)
        {
            int[] mas = new int[arr.GetLength(0)];

            for (int i = 0; i < arr.GetLength(0); i++)
                mas[i] = arr[i, k];

            return mas;
        }

    }
}
