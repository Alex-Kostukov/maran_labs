﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{

    /*составить программу по объектно-ориентированной методике.
     *  В программе должно быть не менее двух классов, связанных 
     *  с отношением наследования. Все массивы - динамические. 
     *  Наличие конструктора - обязательно.
     
         Определить столбец прямогольной матрицы с максимальной суммой элементов
         и, если его номер больше заданного, сф-ть м-цу из ст-ов исходной до найденного ст-ца, 
         иначе сформировать массив из элементов заданного столбца*/

    class Matrix
    {
        public int[,] arr;
        public Matrix(int m)
        {
            Random rnd = new Random();
            arr = new int[m, m];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < m; j++)
                    arr[i, j] = rnd.Next(1, 101) ;
        }
        public int[] lastColumn()
        {
            int[] lastest = new int[arr.GetLength(0)];
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                lastest[i] =arr[i, arr.GetLength(0) - 1];

            }
            return lastest;
        }
        public int this[int p, int q]
        {
            get
            {
                return arr[p, q];
            }
            set
            {
                arr[p, q] = value;
            }
        }
        private bool isSimple(int n)
        {

            for (int i = 2; i <= Math.Sqrt(n) + 1; i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        public int sumOfSimpleNumbers()
        {
            int counter = 0;
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(0); j++)
                {

                    if (isSimple(arr[i, j]))
                    {
                        counter++;
                    }

                }
            }
            return counter;
        }

        

        public bool Condition()
        {
            return (sumOfSimpleNumbers() >= (arr.GetLength(0) * arr.GetLength(0)) / 2);     
        }
    }

    class Exercise : Matrix
    {
        public Exercise(int m) : base(m)
        {
        }
        public int[,] ReInit(int k)
        {
            int[,] arr1;
            arr1 = new int[arr.GetLength(0), k];

            for (int i = 0; i < arr1.GetLength(0); i++)
                for (int j = 0; j < arr1.GetLength(1); j++)
                    arr1[i, j] = arr[i, j];

            return arr1;
        }

        public int[] MatrToArr(int k)
        {
            int[] arr1;
            arr1 = new int[arr.GetLength(0)];

            for (int i = 0; i < arr1.GetLength(0); i++)
                    arr1[i] = arr[i, k];

            return arr1;
        }
    }
        
}
