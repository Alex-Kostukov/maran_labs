﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsFormsApplication1
{

    /*составить программу по объектно-ориентированной методике.
     *  В программе должно быть не менее двух классов, связанных 
     *  с отношением наследования. Всемассивы- динамические. 
     *  Наличие конструктора - обязательно.
     
         Определить столбец прямогольной матрицы с максимальной суммой элементов
         и, если его номер больше заданного, сфо-ть м-цу из ст-ов исходной до найденного ст-ца, 
         иначе сформировать массив из элементов заданного столбца*/

    public partial class Form1 : Form
    {
        Exercise a;
        int[,] b;
        int[] c;

        public Form1()
        {
            InitializeComponent();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void CreateMatrix_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            a = new Exercise(n);

            matr.RowCount = n;
            matr.ColumnCount = n;
            for (int i = 0; i < matr.RowCount; i++)
                for (int j = 0; j < matr.ColumnCount; j++)
                    matr.Rows[i].Cells[j].Value = a[i, j].ToString();
        }

        private void Work_Click(object sender, EventArgs e)
        {

      //      int n = Convert.ToInt32(textBox1.Text);
       //     a = new Exercise(n);

       //     matr.RowCount = n;
        //    matr.ColumnCount = n;
            for (int i = 0; i < matr.RowCount; i++)
                for (int j = 0; j < matr.ColumnCount; j++)
                    a[i, j] = Int32.Parse(matr.Rows[i].Cells[j].Value.ToString());


            textBox2.Clear();

            if (a.Condition())
            {
                int[] last = a.lastColumn();
                Array.Sort(last);
                Array.Reverse(last);
                for (int i = 0; i < matr.RowCount; i++)
                {
                    textBox2.Text += last[i] + " " ;
                }
            }
            else
            {

                textBox2.Text = "Количество простых числе меньше половины";
               
            }

        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != String.Empty) {
                CreateMatrix.Enabled = true;
                Work.Enabled = true;
           } else
                CreateMatrix.Enabled = false;
        }
    }
}
