﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            /*Определить столбец прямоугольной матрицы с максимальной 
             * суммой жлементов и, если его номер больше заданного, 
             * сформировать матрицу из стобцов исходной до найднного столбца,
             *  иначе сформировать массивиз элементов заданного столбца*/

            double[,] arr1, arr2;
            double[] arr3;
            int m, n, k, p;

            Console.WriteLine("Input sizes of matrix: ");
            m = Convert.ToInt32(Console.ReadLine());
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input index: ");
            k = Convert.ToInt32(Console.ReadLine());

            InputArr2(m, n, out arr1);
            OutputArr(ref arr1);
            p = ColMaxSum(arr1);
            Console.WriteLine("Index of column with biggest sum of elements: " + p);
            if (p > k)
            {
                ShrinkMatr(arr1,p+1,out arr2);   //сфо-ать м-цу из стобцов исх. до найднного столбца,(включительно p+1, строго до p)
                Console.WriteLine(p+" > "+k);
                OutputArr(ref arr2);
            }
            else
            {
                ArrFromCol(arr1,k,out arr3);   //сформировать массивиз элементов заданного столбца
                Console.WriteLine(p + " <= " + k);
                OutputArr(ref arr3);
            }
            Console.ReadLine();
        }

        static void InputArr1(int m, int n, out double[,] arr)
        {
            Console.WriteLine("Input array elements: ");
            arr = new double[m, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    arr[i, j] = Convert.ToInt32(Console.Read());
                }
                Console.WriteLine();
            }

        }
        static void InputArr2(int m, int n, out double[,] arr)
        {
            Random rnd = new Random();
            double r;
            arr = new double[m, n];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < n; j++)
                {
                    r = rnd.NextDouble();
                    arr[i, j] = 100*r;
                }

        }
        static int ColMaxSum(double[,] arr)
        {
            double[] sum;
            sum = new double[arr.GetLength(1)];
            int p;

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                sum[i] = 0;
                for (int j = 0; j < arr.GetLength(1); j++)
                    sum[i] += arr[i, j];
            }

            p = IndexOfMax(sum);

            return p;
        }
        static int IndexOfMax(double[] arr)
        { 
            int p;
            double max;

            max = arr[0];
            p = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] > max)
                {
                    max = arr[i];
                    p = i;
                }
            }

            return p;
        }
        static void ShrinkMatr(double[,] arr1, int p, out double[,] arr2)
        {
            arr2 = new double[arr1.GetLength(0), p];

            for (int i = 0; i < arr1.GetLength(0); i++)
                for (int j = 0; j < p; j++)
                    arr2[i, j] = arr1[i, j];
        }
        static void ArrFromCol(double[,] arr1, int p, out double[] arr2)
        {
            arr2 = new double[arr1.GetLength(0)];

            for (int i = 0; i < arr1.GetLength(0); i++)
            {
                arr2[i] = arr1[i,p];
            }
        }
        static void OutputArr(ref double[,] arr)
        {
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                    Console.Write(arr[i, j].ToString("F1")+ "\t");
                Console.WriteLine();
            }
        }
        static void OutputArr(ref double[] arr)
        {
            for (int j = 0; j < arr.Length; j++)
                Console.Write(arr[j].ToString("F1") + "\t");
        }
    }
}
