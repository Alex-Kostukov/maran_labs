﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{

    /*составить программу по объектно-ориентированной методике.
     *  В программе должно быть не менее двух классов, связанных 
     *  с отношением наследования. Все массивы - динамические. 
     *  Наличие конструктора - обязательно.
     
         Определить столбец прямогольной матрицы с максимальной суммой элементов
         и, если его номер больше заданного, сф-ть м-цу из ст-ов исходной до найденного ст-ца, 
         иначе сформировать массив из элементов заданного столбца*/

    class Matrix
    {
        protected double[,] arr;
        public Matrix(int m)
        {
            Random rnd = new Random();
            arr = new double[m, m];
            for (int i = 0; i < m; i++)
                for (int j = 0; j < m; j++)
                    arr[i, j] = rnd.NextDouble() * 100 - 50;
        }

        protected int ColOfMAxSum()
        {
            double[] s;
            s = new double[arr.GetLength(1)];
            int k = 0;

            for (int i = 0; i < arr.GetLength(0); i++)
                for (int j = 0; j < arr.GetLength(1); j++)
                    s[i] += arr[i, j];

            double maxs = s[0];
            for (int i = 0; i < arr.GetLength(1); i++)
                if(s[i]>maxs)
                {
                    maxs = s[i];
                    k = i;
                }
            return k;
        }
    }

    class Exercise : Matrix
    {
        public Exercise(int m) : base(m)
        {
        }
        public double[,] ReInit(int k)
        {
            double[,] arr1;
            arr1 = new double[arr.GetLength(0), k];


            for (int i = 0; i < arr1.GetLength(0); i++)
                for (int j = 0; j < arr1.GetLength(1); j++)
                    arr1[i, j] = arr[i, j];

            return arr1;
        }

        public double[] MatrToArr(int k)
        {
            double[] arr1;
            arr1 = new double[arr.GetLength(0)];

            for (int i = 0; i < arr1.GetLength(0); i++)
                    arr1[i] = arr[i, k];

            return arr1;
        }
    }
        
}
